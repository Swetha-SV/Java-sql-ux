/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package online_workshop_registration;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author USER
 */
public class Admin extends javax.swing.JFrame {

    /**
     * Creates new form Admin
     */
    public Admin() {
        initComponents();
        populateWorkshopData();
    }
 

private boolean checkIfWorkshopExists(String workshopTitle, String workshopDate, String workshopTime) {
    String url = "jdbc:mysql://localhost:3306/onlineworkshop";
    String username = "root";
    String password = "";

    String query = "SELECT COUNT(*) FROM workshop WHERE workshop_title = ? AND date = ? AND time = ?";
    
    try (Connection conn = DriverManager.getConnection(url, username, password);
         PreparedStatement pstmt = conn.prepareStatement(query)) {
        
        pstmt.setString(1, workshopTitle);
        pstmt.setString(2, workshopDate);
        pstmt.setString(3, workshopTime);
        
        ResultSet rs = pstmt.executeQuery();
        rs.next();
        int count = rs.getInt(1);
        return count > 0;
    } catch (SQLException ex) {
        System.out.println("Error checking workshop existence: " + ex.getMessage());
        return false;
    }
}
private boolean updateWorkshopInDatabase(String workshopTitle, String workshopDate, String workshopInstructor, String workshopPlace, String workshopTime) {
    String url = "jdbc:mysql://localhost:3306/onlineworkshop";
    String username = "root";
    String password = "";

    String query = "UPDATE workshop SET date=?, instructor=?, place=?, time=? WHERE workshop_title=?";
    
    try (Connection conn = DriverManager.getConnection(url, username, password);
         PreparedStatement pstmt = conn.prepareStatement(query)) {
        
        pstmt.setString(1, workshopDate);
        pstmt.setString(2, workshopInstructor);
        pstmt.setString(3, workshopPlace);
        pstmt.setString(4, workshopTime);
        pstmt.setString(5, workshopTitle);
        
        int rowsUpdated = pstmt.executeUpdate();
        return rowsUpdated > 0;
    } catch (SQLException ex) {
        System.out.println("Error updating workshop: " + ex.getMessage());
        return false;
    }
}

private boolean addWorkshopToDatabase(String workshopTitle, String workshopDate, String workshopInstructor, String workshopPlace, String workshopTime) {
    String url = "jdbc:mysql://localhost:3306/onlineworkshop";
    String username = "root";
    String password = "";

    String query = "INSERT INTO workshop (workshop_title, date, instructor, place, time) VALUES (?, ?, ?, ?, ?)";
    
    try (Connection conn = DriverManager.getConnection(url, username, password);
         PreparedStatement pstmt = conn.prepareStatement(query)) {
        
        pstmt.setString(1, workshopTitle);
        pstmt.setString(2, workshopDate);
        pstmt.setString(3, workshopInstructor);
        pstmt.setString(4, workshopPlace);
        pstmt.setString(5, workshopTime);
        
        int rowsInserted = pstmt.executeUpdate();
        return rowsInserted > 0;
    } catch (SQLException ex) {
        System.out.println("Error adding workshop to database: " + ex.getMessage());
        return false;
    }
}
private boolean checkIfWorkshopExists(String workshopTitle) {
    String url = "jdbc:mysql://localhost:3306/onlineworkshop";
    String username = "root";
    String password = "";

    String query = "SELECT COUNT(*) FROM workshop WHERE workshop_title=?";
    
    try (Connection conn = DriverManager.getConnection(url, username, password);
         PreparedStatement pstmt = conn.prepareStatement(query)) {
        
        pstmt.setString(1, workshopTitle);
        
        ResultSet rs = pstmt.executeQuery();
        rs.next();
        int count = rs.getInt(1);
        return count > 0;
    } catch (SQLException ex) {
        System.out.println("Error checking workshop existence: " + ex.getMessage());
        return false;
    }
}
 private void populateWorkshopData() {
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Workshop Title");
        model.addColumn("Date");
        model.addColumn("Instructor");
        model.addColumn("Place");
        model.addColumn("Time");

        // Database connection parameters
        String url = "jdbc:mysql://localhost:3306/onlineworkshop";
        String username = "root";
        String password = "";

        try {
            Connection conn = DriverManager.getConnection(url, username, password);
            String sql;
          
            sql = "SELECT workshop_title, date, instructor, place, time FROM workshop";
  
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            boolean found = false;
            while (rs.next()) {
                found = true;
                Object[] row = {
                    rs.getString("workshop_title"),
                    rs.getString("date"),
                    rs.getString("instructor"),
                    rs.getString("place"),
                    rs.getString("time")
                };
                model.addRow(row);
            }
            if (!found) {
                // If no workshops found for the specified place
                Object[] row = {"No workshops found", "", "", "", ""};
                model.addRow(row);
            }

            rs.close();
            pst.close();
            conn.close();
        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
        }

        jTable2.setModel(model); // Set the populated table model to the JTable
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        instructor = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        date = new javax.swing.JTextField();
        time = new javax.swing.JTextField();
        title = new javax.swing.JTextField();
        reset = new javax.swing.JButton();
        add = new javax.swing.JButton();
        update = new javax.swing.JButton();
        remove = new javax.swing.JButton();
        report = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        place = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("Instructor         :");
        jLabel1.setOpaque(true);
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 260, -1, 30));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel2.setText("Online Workshop registration System");
        jLabel2.setOpaque(true);
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 20, -1, 40));

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable2MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable2);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 130, 740, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel3.setText("Admin Dashboard");
        jLabel3.setOpaque(true);
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 80, -1, 40));

        instructor.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        instructor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                instructorActionPerformed(evt);
            }
        });
        getContentPane().add(instructor, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 260, 420, 30));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel4.setText("Updations");
        jLabel4.setOpaque(true);
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 100, -1, 40));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel5.setText("Date                   :");
        jLabel5.setOpaque(true);
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 320, -1, 30));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel6.setText("Time                   :");
        jLabel6.setOpaque(true);
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 380, -1, 30));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel7.setText("workshop_title  :");
        jLabel7.setOpaque(true);
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 200, -1, 30));

        date.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        date.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dateActionPerformed(evt);
            }
        });
        getContentPane().add(date, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 320, 420, 30));

        time.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        time.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                timeActionPerformed(evt);
            }
        });
        getContentPane().add(time, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 380, 420, 30));

        title.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        title.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                titleActionPerformed(evt);
            }
        });
        getContentPane().add(title, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 202, 420, 30));

        reset.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        reset.setText("Reset");
        reset.setOpaque(true);
        reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetActionPerformed(evt);
            }
        });
        getContentPane().add(reset, new org.netbeans.lib.awtextra.AbsoluteConstraints(1210, 520, 110, -1));

        add.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        add.setText("Add");
        add.setOpaque(true);
        add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addActionPerformed(evt);
            }
        });
        getContentPane().add(add, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 520, 90, -1));

        update.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        update.setText("Update");
        update.setOpaque(true);
        update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateActionPerformed(evt);
            }
        });
        getContentPane().add(update, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 520, -1, -1));

        remove.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        remove.setText("Remove");
        remove.setOpaque(true);
        remove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removeActionPerformed(evt);
            }
        });
        getContentPane().add(remove, new org.netbeans.lib.awtextra.AbsoluteConstraints(1070, 520, -1, -1));

        report.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        report.setText("Generate Report");
        report.setOpaque(true);
        report.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reportActionPerformed(evt);
            }
        });
        getContentPane().add(report, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 590, -1, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel8.setText("Place                 :");
        jLabel8.setOpaque(true);
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 450, 110, 30));

        place.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        place.setOpaque(true);
        getContentPane().add(place, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 450, 420, 30));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/online_workshop_registration/wallpaperflare.com_wallpaper (4).jpg"))); // NOI18N
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(-70, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void instructorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_instructorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_instructorActionPerformed

    private void dateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dateActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dateActionPerformed

    private void timeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_timeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_timeActionPerformed

    private void titleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_titleActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_titleActionPerformed

    private void jTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseClicked
        // TODO add your handling code here:
        int selectedRow = jTable2.getSelectedRow();
        if (selectedRow != -1) { // Ensure a row is selected
        // Get data from the selected row in the table model
        String workshopTitle = jTable2.getValueAt(selectedRow, 0).toString();
        String date = jTable2.getValueAt(selectedRow, 1).toString();
        String instructor = jTable2.getValueAt(selectedRow, 2).toString();
        String place = jTable2.getValueAt(selectedRow, 3).toString();
        String time = jTable2.getValueAt(selectedRow, 4).toString();

        // Set data to the text fields
        title.setText(workshopTitle);
        this.date.setText(date);
        this.instructor.setText(instructor);
        this.place.setText(place);
        this.time.setText(time);
    }
        
    }//GEN-LAST:event_jTable2MouseClicked

    private void resetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetActionPerformed
        // TODO add your handling code here:
        title.setText("");
         place.setText("");
          time.setText("");
           date.setText("");
            instructor.setText("");
            populateWorkshopData();
            
    }//GEN-LAST:event_resetActionPerformed
private boolean removeWorkshopFromDatabase(String workshopTitle) {
    String url = "jdbc:mysql://localhost:3306/onlineworkshop";
    String username = "root";
    String password = "";

    String query = "DELETE FROM workshop WHERE workshop_title=?";
    
    try (Connection conn = DriverManager.getConnection(url, username, password);
         PreparedStatement pstmt = conn.prepareStatement(query)) {
        
        pstmt.setString(1, workshopTitle);
        
        int rowsDeleted = pstmt.executeUpdate();
        return rowsDeleted > 0;
    } catch (SQLException ex) {
        title.setText("");
         place.setText("");
          time.setText("");
           date.setText("");
            instructor.setText("");
        System.out.println("Error removing workshop: " + ex.getMessage());
        return false;
    }
}
    private void addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addActionPerformed
        // TODO add your handling code here:
        String workshopTitle = title.getText();
    String workshopDate = date.getText();
    String workshopInstructor = instructor.getText();
    String workshopPlace = place.getText();
    String workshopTime = time.getText();

    // Check if any fields are empty
    if (workshopTitle.isEmpty() || workshopDate.isEmpty() || workshopInstructor.isEmpty() ||
            workshopPlace.isEmpty() || workshopTime.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Check if the workshop already exists
    boolean workshopExists = checkIfWorkshopExists(workshopTitle, workshopDate, workshopTime);
    if (workshopExists) {
        JOptionPane.showMessageDialog(this, "Workshop already exists.", "Error", JOptionPane.ERROR_MESSAGE);
        title.setText("");
         place.setText("");
          time.setText("");
           date.setText("");
            instructor.setText("");

        return;
    }

    // Insert the workshop into the database
    boolean inserted = addWorkshopToDatabase(workshopTitle, workshopDate, workshopInstructor, workshopPlace, workshopTime);
    if (inserted) {
        JOptionPane.showMessageDialog(this, "Workshop added successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
        // Populate the table again
        title.setText("");
         place.setText("");
          time.setText("");
           date.setText("");
            instructor.setText("");

        populateWorkshopData();
    } else {
        title.setText("");
         place.setText("");
          time.setText("");
           date.setText("");
            instructor.setText("");
        JOptionPane.showMessageDialog(this, "Error adding workshop.", "Error", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_addActionPerformed

    private void updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateActionPerformed
        // TODO add your handling code here:
        String workshopTitle = title.getText();
    String workshopDate = date.getText();
    String workshopInstructor = instructor.getText();
    String workshopPlace = place.getText();
    String workshopTime = time.getText();

    // Check if any fields are empty
    if (workshopTitle.isEmpty() || workshopDate.isEmpty() || workshopInstructor.isEmpty() ||
            workshopPlace.isEmpty() || workshopTime.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Check if the workshop exists
    boolean workshopExists = checkIfWorkshopExists(workshopTitle);
    if (!workshopExists) {
        title.setText("");
         place.setText("");
          time.setText("");
           date.setText("");
            instructor.setText("");
        JOptionPane.showMessageDialog(this, "Workshop does not exist.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Update the workshop in the database
    boolean updated = updateWorkshopInDatabase(workshopTitle, workshopDate, workshopInstructor, workshopPlace, workshopTime);
    if (updated) {
        JOptionPane.showMessageDialog(this, "Workshop updated successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
        // Populate the table again
        title.setText("");
         place.setText("");
          time.setText("");
           date.setText("");
            instructor.setText("");
        populateWorkshopData();
    } else {
        title.setText("");
         place.setText("");
          time.setText("");
           date.setText("");
            instructor.setText("");
        JOptionPane.showMessageDialog(this, "Error updating workshop.", "Error", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_updateActionPerformed

    private void removeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removeActionPerformed
        // TODO add your handling code here:
        String workshopTitle = title.getText();

    // Check if the workshop title is empty
    if (workshopTitle.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please enter workshop title.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Check if the workshop exists
    boolean workshopExists = checkIfWorkshopExists(workshopTitle);
    if (!workshopExists) {
        title.setText("");
         place.setText("");
          time.setText("");
           date.setText("");
            instructor.setText("");
        JOptionPane.showMessageDialog(this, "Workshop does not exist.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Remove the workshop from the database
    boolean removed = removeWorkshopFromDatabase(workshopTitle);
    if (removed) {
        JOptionPane.showMessageDialog(this, "Workshop removed successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
        // Populate the table again
        title.setText("");
         place.setText("");
          time.setText("");
           date.setText("");
            instructor.setText("");
        populateWorkshopData();
    } else {
        title.setText("");
         place.setText("");
          time.setText("");
           date.setText("");
            instructor.setText("");
        JOptionPane.showMessageDialog(this, "Error removing workshop.", "Error", JOptionPane.ERROR_MESSAGE);
    }
        
    }//GEN-LAST:event_removeActionPerformed

    private void reportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reportActionPerformed
        // TODO add your handling code here:
        String workshopTitle = title.getText().trim();

    DefaultTableModel model = new DefaultTableModel();
    model.addColumn("Workshop Title");
    model.addColumn("User Count");

    String url = "jdbc:mysql://localhost:3306/onlineworkshop";
    String username = "root";
    String password = "";

    try (Connection conn = DriverManager.getConnection(url, username, password)) {
        String query;
        if (workshopTitle.isEmpty()) {
            // If title field is empty, fetch counts for all workshops
            query = "SELECT workshop_title, COUNT(DISTINCT email) AS user_count FROM enrollment GROUP BY workshop_title";
        } else {
            // If title field is not empty, fetch counts for the specified workshop
            query = "SELECT email, COUNT(*) AS user_count FROM enrollment WHERE workshop_title = ? GROUP BY email";
        }

        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            if (!workshopTitle.isEmpty()) {
                pstmt.setString(1, workshopTitle);
            }

            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                String title = workshopTitle.isEmpty() ? rs.getString("workshop_title") : rs.getString("email");
                int count = rs.getInt("user_count");
                model.addRow(new Object[]{title, count});
            }
        }
    } catch (SQLException ex) {
        System.out.println("Error fetching workshop report: " + ex.getMessage());
    }

    jTable2.setModel(model);
    }//GEN-LAST:event_reportActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Admin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton add;
    private javax.swing.JTextField date;
    private javax.swing.JTextField instructor;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextField place;
    private javax.swing.JButton remove;
    private javax.swing.JButton report;
    private javax.swing.JButton reset;
    private javax.swing.JTextField time;
    private javax.swing.JTextField title;
    private javax.swing.JButton update;
    // End of variables declaration//GEN-END:variables
}
